package Observer;


public interface DisplayElement {
  public void display();
  //화면 출력 호출 메소드
}
