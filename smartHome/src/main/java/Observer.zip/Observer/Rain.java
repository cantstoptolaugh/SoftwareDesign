
package Observer;

public class Rain implements WeatherKinds {
    public void Rain(){
    }
    public void Weather(){
       System.out.println("It's riany day");
    }

    public void weather() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
}