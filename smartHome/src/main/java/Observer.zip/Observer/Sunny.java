
package Observer;


public class Sunny implements WeatherKinds {
    public void Cloud(){
    
    }
    
     public void Weather(){
        System.out.println("It's Sunny day");
    }   

    public void weather() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}