
package Observer;


public class TomorrowWeather extends WeatherState{
    public TomorrowWeather(){
       weatherkinds = new Snow();
    }
    
}
