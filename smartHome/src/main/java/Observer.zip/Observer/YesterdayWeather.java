
package Observer;

public class YesterdayWeather extends WeatherState {
    public YesterdayWeather(){
        weatherkinds = new Rain();
    }
    
}
