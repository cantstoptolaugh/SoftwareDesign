package Observer;

public interface WeatherKinds {
    public void Weather();
}