
package Observer;


public class TodayWeather extends WeatherState {
    public TodayWeather(){
         weatherkinds = new Sunny();
    }
   
                          
    }

